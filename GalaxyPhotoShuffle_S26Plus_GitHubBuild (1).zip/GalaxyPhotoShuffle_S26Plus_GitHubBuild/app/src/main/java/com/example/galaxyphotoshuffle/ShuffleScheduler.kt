package com.example.galaxyphotoshuffle

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.concurrent.TimeUnit

object ShuffleScheduler {
    private const val REQUEST = 2001

    fun schedule(context: Context) {
        val settings = SettingsStore(context)
        val am = context.getSystemService(AlarmManager::class.java)

        val intent = Intent(context, ShuffleReceiver::class.java)
            .setAction("com.example.galaxyphotoshuffle.SHUFFLE")

        val pi = PendingIntent.getBroadcast(
            context, REQUEST, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        am.cancel(pi)

        val minutes = when (settings.interval) {
            0 -> return
            1 -> 30L
            2 -> 60L
            3 -> 360L
            else -> 1440L
        }

        val interval = TimeUnit.MINUTES.toMillis(minutes)
        am.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + interval,
            interval,
            pi
        )
    }
}
