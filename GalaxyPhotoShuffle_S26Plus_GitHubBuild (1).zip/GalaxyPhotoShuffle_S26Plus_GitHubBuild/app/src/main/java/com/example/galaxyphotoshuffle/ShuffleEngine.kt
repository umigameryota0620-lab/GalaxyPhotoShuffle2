package com.example.galaxyphotoshuffle

import android.app.WallpaperManager
import android.content.Context
import android.net.Uri
import kotlin.random.Random

class ShuffleEngine(private val context: Context) {
    private val settings = SettingsStore(context)

    fun shuffleNow() {
        if (settings.lockEnabled) applyRandom("lock", WallpaperManager.FLAG_LOCK)
        if (settings.homeEnabled) applyRandom("home", WallpaperManager.FLAG_SYSTEM)
    }

    private fun applyRandom(poolName: String, flag: Int) {
        val pool = settings.getPool(poolName)
        if (pool.isEmpty()) return

        val last = settings.getLast(poolName)
        val candidates = if (pool.size > 1) pool.filter { it != last } else pool
        val chosen = candidates[Random.nextInt(candidates.size)]
        val uri = Uri.parse(chosen)

        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                WallpaperManager.getInstance(context)
                    .setStream(input, null, true, flag)
            }
            settings.setLast(poolName, chosen)
        } catch (_: Exception) {
            // Samsung/Android may reject a wallpaper change under some system states.
        }
    }
}
