package com.example.galaxyphotoshuffle

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ShuffleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_BOOT_COMPLETED -> ShuffleScheduler.schedule(context)
            "com.example.galaxyphotoshuffle.SHUFFLE" -> ShuffleEngine(context).shuffleNow()
        }
    }
}
