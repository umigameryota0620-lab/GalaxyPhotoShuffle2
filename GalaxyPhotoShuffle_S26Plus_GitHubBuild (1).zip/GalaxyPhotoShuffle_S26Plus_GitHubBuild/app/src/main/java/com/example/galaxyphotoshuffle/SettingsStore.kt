package com.example.galaxyphotoshuffle

import android.content.Context

class SettingsStore(context: Context) {
    private val p = context.getSharedPreferences("photo_shuffle", Context.MODE_PRIVATE)

    var lockEnabled: Boolean
        get() = p.getBoolean("lock_enabled", true)
        set(v) = p.edit().putBoolean("lock_enabled", v).apply()

    var homeEnabled: Boolean
        get() = p.getBoolean("home_enabled", true)
        set(v) = p.edit().putBoolean("home_enabled", v).apply()

    var interval: Int
        get() = p.getInt("interval", 2)
        set(v) = p.edit().putInt("interval", v).apply()

    fun getPool(name: String): MutableList<String> =
        p.getStringSet(name, emptySet())?.toMutableList() ?: mutableListOf()

    fun savePool(name: String, values: Collection<String>) =
        p.edit().putStringSet(name, values.toSet()).apply()

    fun getLast(name: String): String? = p.getString("last_$name", null)

    fun setLast(name: String, value: String) =
        p.edit().putString("last_$name", value).apply()
}
