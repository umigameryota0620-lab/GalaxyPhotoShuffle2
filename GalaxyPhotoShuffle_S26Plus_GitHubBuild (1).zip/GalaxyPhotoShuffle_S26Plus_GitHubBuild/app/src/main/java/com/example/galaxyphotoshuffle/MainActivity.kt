package com.example.galaxyphotoshuffle

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import android.graphics.Color
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {

    private lateinit var settings: SettingsStore
    private lateinit var lockCount: TextView
    private lateinit var homeCount: TextView

    private val pickLock = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> saveUris("lock", uris.map { it.toString() }, 15) }

    private val pickHome = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> saveUris("home", uris.map { it.toString() }, 50) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 40, 36, 32)
        }

        root.addView(TextView(this).apply {
            text = "Galaxyフォトシャッフル"
            textSize = 27f
            setTextColor(Color.BLACK)
            setPadding(0, 0, 0, 8)
        })

        root.addView(TextView(this).apply {
            text = "Galaxy S26+ / Android 16 / One UI 8.5向け"
            textSize = 14f
            setPadding(0, 0, 0, 28)
        })

        root.addView(TextView(this).apply {
            text = "AQUOSの「ロック・ホームフォトシャッフル」に近い操作で、選んだ写真を壁紙としてランダムに切り替えます。"
            textSize = 15f
            setPadding(0, 0, 0, 24)
        })

        val lock = Switch(this).apply {
            text = "ロック画面をシャッフル"
            textSize = 17f
            isChecked = settings.lockEnabled
            setOnCheckedChangeListener { _, v -> settings.lockEnabled = v }
        }
        root.addView(lock)

        val lockButton = Button(this).apply {
            text = "ロック画面の写真を選ぶ（最大15枚）"
            setOnClickListener { pickLock.launch("image/*") }
        }
        root.addView(lockButton)

        lockCount = countText()
        root.addView(lockCount)

        val home = Switch(this).apply {
            text = "ホーム画面をシャッフル"
            textSize = 17f
            isChecked = settings.homeEnabled
            setOnCheckedChangeListener { _, v -> settings.homeEnabled = v }
        }
        root.addView(home)

        val homeButton = Button(this).apply {
            text = "ホーム画面の写真を選ぶ（最大50枚）"
            setOnClickListener { pickHome.launch("image/*") }
        }
        root.addView(homeButton)

        homeCount = countText()
        root.addView(homeCount)

        root.addView(TextView(this).apply {
            text = "シャッフル間隔"
            textSize = 17f
            setPadding(0, 22, 0, 4)
        })

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            arrayOf("停止", "30分", "1時間", "6時間", "1日")
        )
        spinner.setSelection(settings.interval)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                settings.interval = position
                if (position != 0) ShuffleScheduler.schedule(this@MainActivity)
            }
        }
        root.addView(spinner)

        val now = Button(this).apply {
            text = "今すぐシャッフル"
            setOnClickListener {
                ShuffleEngine(this@MainActivity).shuffleNow()
                Toast.makeText(context, "壁紙を変更しました", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(now)

        val enable = Button(this).apply {
            text = "シャッフルを有効にする"
            setOnClickListener {
                ShuffleScheduler.schedule(this@MainActivity)
                Toast.makeText(context, "設定を保存しました", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(enable)

        root.addView(TextView(this).apply {
            text = "Galaxyの仕様上、複数枚の写真をシステム標準で設定できるのはロック画面です。ホーム画面はこのアプリが1枚ずつ壁紙を切り替える方式です。One UIの省電力設定などにより、定期実行のタイミングが遅れる場合があります。"
            textSize = 13f
            setPadding(0, 24, 0, 0)
        })

        setContentView(root)
        refreshCounts()
    }

    private fun countText() = TextView(this).apply {
        textSize = 14f
        setPadding(0, 2, 0, 8)
    }

    private fun refreshCounts() {
        lockCount.text = "選択中：${settings.getPool("lock").size}枚"
        homeCount.text = "選択中：${settings.getPool("home").size}枚"
    }

    private fun saveUris(pool: String, incoming: List<String>, max: Int) {
        if (incoming.isEmpty()) return
        val current = settings.getPool(pool)
        val merged = (current + incoming).distinct().take(max)

        settings.savePool(pool, merged)
        refreshCounts()

        Toast.makeText(
            this,
            if (incoming.size + current.size > max) "最大${max}枚まで登録しました"
            else "${incoming.size}枚を追加しました",
            Toast.LENGTH_SHORT
        ).show()
    }
}
